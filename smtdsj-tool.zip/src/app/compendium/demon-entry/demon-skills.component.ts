import { Component, ChangeDetectionStrategy, Input, OnChanges, Renderer2 } from '@angular/core';

import { ElementOrder } from '../models/constants';
import { Skill } from '../models/models';
import { Compendium } from '../models/compendium';

import { SortedTableHeaderComponent, SortedTableComponent } from '../sorted-table/sorted-table.component';

@Component({
    selector: 'app-demon-skills',
    changeDetection: ChangeDetectionStrategy.OnPush,
    template: `
        <table>
            <thead>
                <tr>
                    <th colspan="8"><ng-content></ng-content></th>
                </tr>
                <tr>
                    <th>Element</th>
                    <th>Name</th>
                    <th>Cost</th>
                    <th>Effect</th>
                    <th>Power</th>
                    <th>Accuracy</th>
                    <th>Inherit</th>
                    <th>Rank</th>
                </tr>
            </thead>
            <tbody>
                <tr *ngFor="let data of compendium.getSkills(skills)">
                    <td><div class="element-icon {{ data.element }}">{{ data.element }}</div></td>
                    <td>{{ data.name }}</td>
                    <td>{{ data.cost }}</td>
                    <td>{{ data.effect }}</td>
                    <td>{{ data.power }}</td>
                    <td>{{ data.accuracy }}</td>
                    <td><div class="element-icon {{ data.inherit }}">{{ data.inherit }}</div></td>
                    <td>{{ data.rank }}</td>
                </tr>
            </tbody>
        </table>
    `
})
export class DemonSkillsComponent {
    @Input() compendium: Compendium;
    @Input() skills: string[];
}
