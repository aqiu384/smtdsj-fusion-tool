import { Component, ChangeDetectionStrategy, ChangeDetectorRef, OnInit, OnDestroy, Type } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Subscription } from 'rxjs/Subscription';

import { BaseStats, ResistanceElements, Ailments, APP_TITLE } from '../models/constants';
import { Demon } from '../models/models';
import { Compendium } from '../models/compendium';

import { DemonSkillsComponent } from './demon-skills.component';
import { CompendiumNavbarComponent } from '../compendium-navbar.component';
import { CurrentDemonService } from '../services/current-demon.service';
import { FusionDataService } from '../services/fusion-data.service';

@Component({
    selector: 'app-demon-entry',
    changeDetection: ChangeDetectionStrategy.OnPush,
    template: `
        <ng-container *ngIf="demon">
            <table>
                <thead>
                    <tr>
                        <th [style.width.%]="1" colSpan="{{ statHeaders.length }}">
                            Lvl {{ demon.lvl }}
                            {{ demon.race }}
                            {{ name }}
                        </th>
                    </tr>
                    <tr>
                        <th [style.width.%]="1" *ngFor="let stat of statHeaders">{{ stat }}</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td *ngFor="let stat of demon.stats">{{ stat }}</td>
                    </tr>
                </tbody>
            </table>
            <table>
                <thead>
                    <tr><th colspan="17">Resistances</th></tr>
                    <tr>
                        <th [style.width.%]="50" colSpan="8">Elemental</th>
                        <th [style.width.%]="50" colSpan="9">Ailment</th>
                    </tr>
                    <tr>
                        <th *ngFor="let element of resistanceHeaders">
                            <div class="element-icon {{ element }}"></div>
                        </th>
                        <th *ngFor="let ailment of ailmentHeaders">{{ ailment }}</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td *ngFor="let resist of demon.resists"
                        class="resists {{ resist }}">
                            {{ resist }}
                        </td>
                        <td *ngFor="let ailment of demon.ailments">{{ ailment }}</td>
                    </tr>
                </tbody>
            </table>
            <app-demon-skills [compendium]="compendium" [skills]="demon.skills">
                Innate Skills
            </app-demon-skills>
            <app-demon-skills [compendium]="compendium" [skills]="demon.source">
                D-source Skills
            </app-demon-skills>
            <router-outlet></router-outlet>
        </ng-container>
        <ng-container *ngIf="!demon">
            <table>
                <thead>
                    <tr><th>Entry for {{ name }}</th></tr>
                </thead>
                <tbody>
                    <tr><td>Error: Could not find entry in compendium for {{ name }}</td></tr>
                </tbody>
            </table>
        </ng-container>
    `
})
export class DemonEntryComponent implements OnInit, OnDestroy {
    statHeaders = BaseStats;
    resistanceHeaders = ResistanceElements;
    ailmentHeaders = Ailments;

    compendium: Compendium;
    subscriptions: Subscription[] = [];

    name: string;
    demon: Demon;

    constructor(
        private route: ActivatedRoute,
        private title: Title,
        private fusionDataService: FusionDataService,
        private currentDemonService: CurrentDemonService,
        private changeDetectorRef: ChangeDetectorRef
    ) { }

    ngOnInit() {
        const subs: { subject: BehaviorSubject<any>, prop: string }[] = [
            { subject: this.fusionDataService.compendiumBS, prop: 'compendium' },
            { subject: this.currentDemonService.currentNameBS, prop: 'name' },
        ];

        for (const { subject, prop } of subs) {
            this.subscriptions.push(subject.subscribe(val => {
                this[prop] = val;
                this.getDemonEntry();
            }));
        }

        this.route.params.subscribe(params => {
            this.currentDemonService.currentNameBS.next(params['demonName']);
        });
    }

    ngOnDestroy() {
        for (const subscription of this.subscriptions) {
            subscription.unsubscribe();
        }
    }

    getDemonEntry() {
        if (this.compendium && this.name) {
            this.demon = this.compendium.getDemon(this.name);
            this.title.setTitle(`${this.name} - ${APP_TITLE}`);
            this.changeDetectorRef.detectChanges();
        }
    }
}
