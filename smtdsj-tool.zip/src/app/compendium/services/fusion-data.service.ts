import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import { Compendium } from '../models/compendium';
import { FusionChart } from '../models/fusion-chart';

@Injectable()
export class FusionDataService {
    compendium = new Compendium();
    compendiumBS = new BehaviorSubject(this.compendium);

    fusionChart = new FusionChart();
    fusionChartBS = new BehaviorSubject(this.fusionChart);

    updateExcludedDemons(list: any) { }
}
