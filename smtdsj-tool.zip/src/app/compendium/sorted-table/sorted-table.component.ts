import {
    AfterViewChecked,
    Input,
    Output,
    EventEmitter,
    QueryList,
    ElementRef,
    Renderer2,
    ViewChild,
    ViewChildren
} from '@angular/core';

// https://stackoverflow.com/questions/38555744/injection-of-generic-services-in-angular
export class SortedTableHeaderComponent<TData> implements AfterViewChecked {
    static readonly SortDirection = {
        None: 'none',
        Ascending: 'asc',
        Descending: 'desc'
    };

    @ViewChildren('widthCol') widthCols: QueryList<ElementRef>;
    @Output() sortFunChanged = new EventEmitter<(a: TData, b: TData) => number>();
    @Output() colWidthsChanged = new EventEmitter<number[]>();
    private sortAscFun: (a: TData, b: TData) => number;
    private sortAsc: boolean;
    private colBorderWidth: number;
    private setBodyColWidths: boolean;

    constructor(
        private elementRef2: ElementRef,
        private renderer3: Renderer2,
        defaultSortFun: (a: TData, b: TData) => number,
        defaultSortAsc?: boolean,
        colBorderWidth?: number,
        setBodyColWidths?: boolean
    ) {
        this.sortAsc = (defaultSortAsc != null) ? defaultSortAsc : true;
        this.colBorderWidth = (colBorderWidth != null) ? colBorderWidth : 2;
        this.setBodyColWidths = (setBodyColWidths != null) ? setBodyColWidths : true;
        this.sortAscFun = defaultSortFun;
    }

    sortDir(sortFun: (a: TData, b: TData) => number): string {
        return sortFun !== this.sortAscFun ? SortedTableHeaderComponent.SortDirection.None :
            this.sortAsc ? SortedTableHeaderComponent.SortDirection.Ascending :
            SortedTableHeaderComponent.SortDirection.Descending;
    }

    ngAfterViewChecked() {
        this.colWidthsChanged.emit(this.colWidths);
    }

    get colWidths(): number[] {
        const colWidths = [];
        const rows = this.elementRef2.nativeElement.children;

        for (const column of rows[rows.length - 1].children) {
            colWidths.push(column.clientWidth - this.colBorderWidth);
        }

        if (this.setBodyColWidths) {
            this.colWidths = colWidths;
        }

        return colWidths;
    }

    @Input() set colWidths(colWidths: number[]) {
        const rows = this.elementRef2.nativeElement.children;
        const cols = rows[rows.length - 1].children;

        for (let i = 0; i < cols.length; i++) {
            this.renderer3.setStyle(cols[i], 'width', `${colWidths[i]}px`);
        }
    }

    get sortFun(): (a: TData, b: TData) => number {
        return this.sortAsc ? this.sortAscFun : (a, b) => this.sortAscFun(b, a);
    }

    @Input() set sortFun(sortFun: (a: TData, b: TData) => number) {
        this.sortAsc = this.sortAscFun === sortFun ? !this.sortAsc : true;
        this.sortAscFun = sortFun;
        this.sortFunChanged.emit(this.sortFun);
    }
}

export class SortedTableComponent<TData> {
    @ViewChild('stickyHeader') stickyHeader: SortedTableHeaderComponent<TData>;
    private allRowData: TData[] = [];

    get rowData(): TData[] {
        return this.allRowData;
    }

    @Input() set rowData(rowData: TData[]) {
        this.allRowData = rowData;
        this.sort();
    }

    sort() {
        this.allRowData.sort(this.stickyHeader.sortFun);
    }
}
